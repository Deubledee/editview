//esta classe provem da construção inicial do eeditor que passou a ser o Monaco
//trata de receber o input do teclado e interpretalo de acordo com os caracteres inseridos
//contém somente os metodos mais basicos para receber o nome do ficheiro ou directório para serem criados
//ou altertados

//apanha o elemento seleccionado
var n = window.getSelection(),
    msgObj = {
        msg: "",
        count: 0,
        preStr: "",
        postStr: "",
        arrow: false
    }
//função que instacia a classe cursor e envia os dados para serem avaliados
function inputHandler(e, type, folder, elem) {
    if (n.baseNode) {
        var cursor = new Cursor(type, e, folder, elem)
        if (e.innerHTML === type) {
            cursor.to(0);
        } else {
            cursor.to(0)
        }
        n.baseNode.parentElement.onkeydown = function (a) {
            cursor.text(a);
        }
    }
}
//classe que trata o input de acordo com os caracteres inseridos
function Cursor(type, e, folder, elem) {
    var shift = false,
        user = user,
        range = document.createRange(),
        sel = window.getSelection()
    //move o curos para a posição coreecta
    this.to = function (l) {
        //arow === false ? l = l > 1 ? 1 : l : l = l
        range.setStart(sel.anchorNode.parentElement, l)
        range.collapse(true);
        sel.removeAllRanges();
        sel.addRange(range);
    };
    //verifica os caracteres
    this.text = function (a) {
        if (a.code === "Backspace") {
            if (sel.focusOffset > 1) {
                a.preventDefault();
                sel.modify("move", "left", "character")
                document.execCommand("forwardDelete", false)
                msgObj.msg = msgObj.msg.slice(0, msgObj.msg.length - 1)
            } else {
                a.preventDefault();
                if (msgObj.msg.length <= 1 || sel.focusOffset === 0) {
                    sel.anchorNode.parentElement.innerHTML = type
                    this.to(0)
                    msgObj.msg = ""
                }
            }
        } else if (a.key === "Tab" || a.ctrlKey === true) {
            a.preventDefault()
        } else if (a.code.indexOf("Arrow") === 0) {
            a.preventDefault()
            msgObj.arrow = true
            if (a.code === "ArrowLeft") {
                sel.modify("move", "left", "character")
                msgObj.count += 1
                msgObj.msg = sel.anchorNode.parentElement.innerHTML
                msgObj.preStr = msgObj.msg.slice(0, msgObj.msg.length - msgObj.count)
                msgObj.postStr = msgObj.msg.slice(msgObj.msg.length - msgObj.count, msgObj.msg.length)
            }
            if (a.code === "ArrowRight") {
                if (msgObj.count !== 0) {
                    msgObj.count -= 1
                    sel.modify("move", "right", "character")
                } else {
                    sel.modify("move", "left", "character")
                    msgObj.arrow = false
                }
                msgObj.msg = sel.anchorNode.parentElement.innerHTML
                msgObj.preStr = msgObj.msg.slice(0, msgObj.msg.length - msgObj.count)
                msgObj.postStr = msgObj.msg.slice(msgObj.msg.length - msgObj.count, msgObj.msg.length)
            }
        } else if (a.key === "Enter") {
            a.preventDefault();
            var fpath4 = path.join(controlObject.activeTab.children[2].getAttribute("title"), e.srcElement.innerHTML)
            ///////////////////ao fazer enter irá sbmeter o input para ser criado\\\\\\\\\\\\\\\\\\\  
            if (type === "new file") {
                fs.writeFile(fpath4, "", function (err) {
                    if (err) {
                        console.log(err);
                    }
                    if (folder === "main") {
                        createSidebarDirTab(path.join("/", topath), "folder", undefined, "keep")
                    } else {
                        elem.innerHTML = ""
                        createSidebarDirTab(elem.getAttribute("title"), undefined, elem)
                    }

                });
                sel.anchorNode.parentElement.innerHTML = type;
                msgObj.msg = "";
            }
            if (type === "new folder") {
                fs.mkdir(fpath4, 0755, function (err) {
                    if (err) {
                        console.log(err);
                    }
                    if (folder === "main") {
                        createSidebarDirTab(path.join("/", topath), "folder", undefined, "keep")
                    } else {
                        elem.innerHTML = ""
                        createSidebarDirTab(elem.getAttribute("title"), folder, elem)
                    }
                })
                sel.anchorNode.parentElement.innerHTML = type;
                msgObj.msg = "";
            }
            if (type === "renameFile") {
                var joint = sel.baseNode.parentElement.getAttribute("title").split("/")
                joint.pop()
                joint.reverse().pop()
                var topath = joint.reverse().join("/")
                param = sel.baseNode.innerHTML
                let element = getElementFromPath(sel.baseNode.parentElement.getAttribute("title"))
                fs.rename(path.join("/", sel.baseNode.parentElement.getAttribute("title")), path.join("/", topath, msgObj.msg).toString(), err => {
                    if (err) {
                        console.log(err);
                    }
                    //actualiza o file.json e cria o directorio de novo
                    if (folder === "main") {
                        let param = e.srcElement.getAttribute("title").split("/").pop().split(".").reverse().pop()
                        let poped = jf.readFileSync(fpath, "utf8")
                        delete poped["files"][param]
                        msgObj.msg.split(".").reverse().pop()
                        let msg = msgObj.msg.split(".").reverse().pop()
                        poped["files"][msg] = path.join("/", topath, msgObj.msg).split()
                        writeJsonFile("file", poped)
                        createSidebarDirTab(path.join("/", topath), "folder", undefined, "keep")

                        closeTabs(element)
                        msgObj.msg = "";
                    } else { 
                        //duplicado será revisto\\                      
                        let param = e.srcElement.getAttribute("title").split("/").pop().split(".").reverse().pop()
                        let poped = jf.readFileSync(fpath, "utf8")
                        delete poped["files"][param]
                        msgObj.msg.split(".").reverse().pop()
                        let msg = msgObj.msg.split(".").reverse().pop()
                        poped["files"][msg] = path.join("/", topath, msgObj.msg).split()
                        writeJsonFile("file", poped)
                        //\\                        
                        elem.innerHTML = ""
                        createSidebarDirTab(path.join("/", topath), folder, elem)
                        closeTabs(element)
                        msgObj.msg = "";
                    }
                })
            }
            if (type === "renameFolder") {
                var joint = sel.baseNode.parentElement.getAttribute("title").split("/")
                joint.pop()
                joint.reverse().pop()
                var topath = joint.reverse().join("/")
                fs.rename(path.join("/", sel.baseNode.parentElement.getAttribute("title")), path.join("/", topath, msgObj.msg).toString(), err => {
                    if (err) {
                        console.log(err);
                    }
                    if (folder === "main") {
                        //r2.lastElementChild.innerHTML = ""
                        createSidebarDirTab(path.join("/", topath), "folder", undefined, "erase")
                        msgObj.msg = "";
                    } else {
                        elem.innerHTML = ""
                        createSidebarDirTab(path.join("/", topath), folder, elem)
                        msgObj.msg = "";
                    }

                })
            }

            ///////////////////recocloca no estado inicial e fecha o dialogo\\\\\\\\\\\\\\\\\\\
            if (folder === "folder") r2.firstElementChild.children[2].classList.toggle("openDroDown")
        } else if (a.code === "Delete") {
            a.preventDefault();
            if (sel.focusOffset > 1) {
                document.execCommand("forwardDelete", false)
            }
            msgObj.msg = a.srcElement.innerHTML
        } else if (msgObj.arrow === false
            && e.ctrlKey === false
            && event.code.indexOf("Arrow") === -1
            && event.code.indexOf("Shift") === -1
            && event.code.indexOf("Meta") === -1
            && event.key !== "CapsLock"
            && event.key !== "Tab"
            && event.key !== "Alt"
            && event.key !== "Backspace"
            && event.key !== "Enter"
            && event.key !== "Delete") {
            a.preventDefault()
            a.ctrlKey === false ? msgObj.msg += a.key : ""
            if (sel.anchorNode.parentElement.innerHTML === type) {
                sel.anchorNode.nodeValue = "";
            }
            msgObj.preStr.length > 0 ? msgObj.msg = `${msgObj.preStr}${a.key}${msgObj.postStr}` : msgObj.msg = msgObj.msg;
            sel.anchorNode.parentElement.innerHTML = msgObj.msg
            this.to(sel.rangeCount);
            msgObj.preStr = ""
            msgObj.postStr = ""
            msgObj.c++;
            msgObj.arrow = false
        } else {
            msgObj.arrow = false
        }
    }
}
