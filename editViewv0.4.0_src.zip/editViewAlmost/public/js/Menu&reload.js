/**
 * 
 */
const path = require('path')
//const electron = require("electron")
const ipc = require('electron').ipcRenderer
const storage = require('electron-json-storage')
const BrowserWindow = require('electron').remote.BrowserWindow
const remote = require('electron').remote
const Menu = remote.Menu
const MenuItem = remote.MenuItem

let rightClickPosition = null

const menu = new Menu()
const menuItem = new MenuItem({
  label: 'Inspect Element',
  click: () => {
    remote.getCurrentWindow().inspectElement(rightClickPosition.x, rightClickPosition.y)
  }
})
menu.append(menuItem)

window.addEventListener('contextmenu', (e) => {
  e.preventDefault()
  rightClickPosition = { x: e.x, y: e.y }
  menu.popup(remote.getCurrentWindow())
}, false)

ipc.send("get-process-platform")
//template para os menus da aplicação
let template = [{
  label: 'Edit',
  submenu: [{
    label: 'Create Project',
    accelerator: 'CmdOrCtrl+Shift+P',
    click: function () {
      console.log(remote.dialog)
      remote.dialog.showSaveDialog({ properties: ['saveDirectory'] }, function (path) {
        fs.mkdir(path, 0755, function (err) {
          if (err) {
            console.log(err);
          }
          createSidebarDirTab(path, "folder", undefined, "erase")
        })
      })
    }
  }, {
    type: 'separator'
  }, {
    label: 'open flie',
    accelerator: 'CmdOrCtrl+O',
    click: function () {
      remote.dialog.showOpenDialog({ properties: ['openFile'] }, function (files) {
        if (init.win) {
          init.win.loadFile(files)
        } else {
          startEditor(files)
        }
      })
    }
  }, {
    label: 'open folder',
    accelerator: 'CmdOrCtrl+Shift+O',
    click: function () {
      remote.dialog.showOpenDialog({ properties: ['openDirectory'] }, function (path) {
        if (init.win) {
          createSidebarDirTab(path.join(), "folder", undefined, "erase")
          if (cleanTabs.childElementCount > 0) {
            for (var i = 0; i < cleanTabs.childElementCount; i++) {
              cleanTabs.children[i].firstElementChild.click()
            }
          }
        } else {
          startEditor("")
          createSidebarDirTab(path.join(), "folder", undefined, "erase")
          if (cleanTabs.childElementCount > 0) {
            for (var i = 0; i < cleanTabs.childElementCount; i++) {
              cleanTabs.children[i].firstElementChild.click()
            }
          }
        }

      })
    }
  }, {
    type: 'separator'
  }, {
    label: 'save',
    accelerator: 'CmdOrCtrl+S',
    click: function () {
      if (controlObject.activeTab) {
        var fd = fs.openSync(controlObject.activeTab.lastElementChild.getAttribute("title"), "w");
        var buf = Buffer.from(init.win.editor.getValue());
        fs.writeSync(fd, buf, 0, buf.length)
        if (controlObject.ativeTabNotSaved.state === true) {
          ativeTabNotSaved()
          controlObject.model[controlObject.activeTab.lastElementChild.getAttribute("title")].lineCount = init.win.editor.model.getLineCount()
          controlObject.ativeTabNotSaved.state === false
        }
      } else {
        remote.dialog.showSaveDialog(function (files) {
          var fd = fs.openSync(files, "w");
          var buf = Buffer.from(init.win.editor.getValue());
          fs.writeSync(fd, buf, 0, buf.length)
          init.win.loadFile(files.split())
        })
      }
    }
  }, {
    label: 'save as',
    accelerator: 'CmdOrCtrl+Shift+S',
    click: function () {
      remote.dialog.showSaveDialog({ properties: ['file'] }, function (file) {
        var comp = file.split("/")
        var pth = controlObject.activeTab.lastElementChild.getAttribute("title").split("/")
        comp.pop()
        comp.reverse().pop()
        comp.reverse()
        pth.pop()
        pth.reverse().pop()
        pth.reverse()
        var holdPath = comp.join("/")
        var tir = controlObject.direlem[comp.join("/")]
        if (comp.length > pth.length) {
          comp.splice(pth.length, comp.length)
          var longer = true
        }
        //verifica se o ficheiro está a ser guardado noutro directorio (root)
        if (comp.join() === pth.join()) {
          fs.writeFile(file, "", function (err) {
            if (err) {
              console.log(err);
            }
            if (longer === false) {

              r2.lastElementChild.innerHTML = ""
              createSidebarDirTab(path.join("/", holdPath), undefined, r2.lastElementChild.children[0])
            } else {
              controlObject.direlem[path.join("/", holdPath)].innerHTML = ""
              createSidebarDirTab(path.join("/", holdPath), undefined, controlObject.direlem[path.join("/", holdPath)])
            }
          })
        } else {
          fs.writeFile(file, "", function (err) {
            if (err) {
              console.log(err);
            }
            console.log(file, "gravada noutro directório");
          })
        }
      })
    }
  }]
}, {
  label: 'View',
  submenu: [{
    label: 'Minimize',
    accelerator: 'CmdOrCtrl+M',
    role: 'minimize'
  }, {
    label: 'Toggle Full Screen F11',
    accelerator: (function () {
      return 'F11'
    })(),
    click: function (item, focusedWindow) {
      if (focusedWindow) {
        focusedWindow.setFullScreen(!focusedWindow.isFullScreen())
      }
    }
  },{
    label: 'Reload',
    accelerator: (function () {
      return 'CmdOrCtrl+r'
    })(),
    click: function (item, focusedWindow) {
      var r = init.win ? init.win.editor.getModel() : ""
      r ? r.dispose() : ""
      if (focusedWindow) {
        if (focusedWindow.id === 1) {
          BrowserWindow.getAllWindows().forEach(function (win) {
            if (win.id > 1) {
              win.close()
            }
          })
        }
        focusedWindow.reload()
      }
    }
  }, {
    label: 'Toggle Developer Tools',
    accelerator: (function () {
      ipc.send("get-process")
      ipc.on("process", function (sender, process) {
        if (process.platform === 'darwin') {
          return 'Alt+Command+I'
        } else {
          return 'Ctrl+Shift+I'
        }
      })
    })(),
    click: function (item, focusedWindow) {
      if (focusedWindow) {
        focusedWindow.toggleDevTools()
      }
    }
  }]
}, {
  label: 'Help',
  role: 'window',
  submenu: [ {
    label: 'help',
    accelerator: 'F1',
    click: function () {
      let win = new BrowserWindow({
        width: 950,
        minWidth: 900,
        height: 850,
        center: true,
        alwaysOnTop: false,
        //kiosk: true,
        title: "EditView Help"
        //backgroundColor: "66cd00"
      })
      win.loadURL(path.join('file://', __dirname, '../assets/help/help.html'))
      win.show()
      win.focus()
      win.on("close", (e) => {
        win.destroy()
      })
    }
  }]
}]
////////////////////////////////////////////////////////feito pelo electron tutorial\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
function addUpdateMenuItems(items, position) {
  ipc.send("getVersion")
  ipc.on("version", function (sender, platform) {
    if (platform === 'darwin') {
      ipc.send("getName")
      ipc.on("name", function () {
        const name = electron.app.getName()
        template.unshift({
          label: name,
          submenu: [{
            label: `About ${name}`,
            role: 'about'
          }, {
            type: 'separator'
          }, {
            label: 'Services',
            role: 'services',
            submenu: []
          }, {
            type: 'separator'
          }, {
            label: `Hide ${name}`,
            accelerator: 'Command+H',
            role: 'hide'
          }, {
            label: 'Hide Others',
            accelerator: 'Command+Alt+H',
            role: 'hideothers'
          }, {
            label: 'Show All',
            role: 'unhide'
          }, {
            type: 'separator'
          }, {
            label: 'Quit',
            accelerator: 'Command+Q',
            click: function () {
              ipc.send("quit")
            }
          }]
        })
        // Window menu.
        template[3].submenu.push({
          type: 'separator'
        }, {
            label: 'Bring All to Front',
            role: 'front'
          })
        addUpdateMenuItems(template[0].submenu, 1)
      })
    } else if (platform === 'win32') {
      const helpMenu = template[template.length - 1].submenu
      addUpdateMenuItems(helpMenu, 0)
    }
  })
}
////////////////////////////////////////////////////// - f i m - //feito pelo electron tutorial\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

window.onload = function () {
  const menu = Menu.buildFromTemplate(template)
  Menu.setApplicationMenu(menu)

  var path1 = window.location.pathname.split("/")
  //path1[path1.length - 1] = ""
  path1.pop()
  var fpath = path.join(path1.join("/"), "js/folder.json")
  var fpath1 = path.join(path1.join("/"), "js/files.json")
  const jf = require("jsonfile")
  var r = jf.readFileSync(fpath1, "utf8")
  var arr = Object.keys(r)
  var r2 = jf.readFileSync(fpath, "utf8")
  var arr2 = Object.keys(r2)
  init.win = control("javascript", "", "container")
  var t = readJsonFile("file", "filetabStatus", "tabActive")

  if (arr.length > 0) {
    load(r, "files")
  }
  if (arr2.length > 0) {
    load(r2, "folder")
  }
  load(t)
}
//funsção que carrega os ficheiros contidos nas files JSON
function load(r, type) {
  setTimeout(() => {
    if (type === "files") {
      for (par in r[type]) {
        init.win.loadFile(r[type][par][0].split())
      }
    } else if (type === "folder") {
      createSidebarDirTab(r["project"]["path"], r["project"]["dir"], undefined, "keep")
    } else {
      r ? init.win.loadFile(r.split(), getElementFromPath(r)) : 0
    }
  }
    , 1500)
}
