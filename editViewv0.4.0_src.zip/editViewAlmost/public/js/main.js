//require para o electron criado pela equipa do Monaco
function uriFromPath(_path) {
    var pathName = path.resolve(_path).replace(/\\/g, '/');
    if (pathName.length > 0 && pathName.charAt(0) !== '/') {
        pathName = '/' + pathName;
    }
    return encodeURI('file://' + pathName);
}
require.config({
    baseUrl: uriFromPath(path.join(__dirname, '../node_modules/monaco-editor/min'))
});
// workaround monaco-css not understanding the environment
self.module = undefined;
// workaround monaco-typescript not understanding the environment
self.process.browser = true;


///////////////////////////////////função principal de controlo do editor//////////////////////////
function control(lang, file, element, files) {
    //este objeto irá ser retornado com metodos criados e do Monaco
    var win = {}
    //instaciamento de elementos
    var modes = document.querySelector(".modes"),
        select = modes.appendChild(document.createElement("select")),
        container = document.querySelector(".tabopen")
    //dimençãp do select que contém as lingiuagens disponiveis
    select.style.width = "123px"
    //reqiure do editor\\ função callback com ambiente typescript
    //não permite hoisting
    require(['vs/editor/editor.main'], function () {
        //função para definir a lingua acrivada no select
        function setLang(lang) {
            var i
            if (win.selected) {
                select.options[win.selected].removeAttribute("selected")
            }
            for (i = 0; i < select.childElementCount; i++) {
                if (select.childNodes[i].value === lang) {
                    select.childNodes[i].setAttribute("selected", "selected")
                    win.selected = i
                }
            }
        }
        //função que muda de Model (conjunto de metodos que recebem o input e controlam o que o editor
        //vai interpretar, relativamente as caracteristicas do input)
        function changeModel(lang, newFile, tab) {
            if (win.editor) {
                var Files = newFile ? newFile : win.editor ? win.editor.getValue() : ""
                var oldModel = win.editor.getModel();
                var newModel = monaco.editor.createModel(Files, lang);
                if (oldModel) {
                    oldModel.destroy();
                }
                win.editor.setModel(newModel);
                setLang(lang)
            }
        }
        //modelo que é carregado quando contron() é executado
        function firstModel(lang, newFile) {
            var newModel = monaco.editor.createModel(newFile, lang);
            return newModel
        }
        //instaciação do editor para a variavel editor
        var editor = monaco.editor.create(document.getElementById(element), {
            module: firstModel(lang, file),
            theme: "vs-dark"
        });
        //não necesita de de ser criado nesta altura para já fica\\ 
        win.editor = editor
        ///////////////////////////////deprecada\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
        function changeLang(lang, newFile) {
            if (win.editor) {
                var Files = newFile ? newFile : win.editor ? win.editor.getValue() : ""
                var oldModel = win.editor.getModel();
                var newModel = monaco.editor.createModel(Files, lang);
                if (win.selected) {
                    select.options[win.selected].removeAttribute("selected")
                }
                win.editor.setModel(newModel);
                if (oldModel) {
                    oldModel.destroy();
                }
            }
        }
        //\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
        //função que carrega um ficheiro  
        function loadFile(file, tab) {
            var arr = file[0]
            var lang = mime.lookup(arr).split("/").pop(),
                ext = mime.extension(mime.lookup(file[0])),
                fileName = file.join().split("/").pop().split(".").reverse().pop(),
                fileExtention = file.join().split("/").pop().split(".").reverse(),
                finalext = { ext: "" }
            //será revisto\\ 
            //mime não está a fazer o seu trabalho como deve de ser terá de ser implementada outro método\\
            var buffer = fs.readFileSync(arr, "utf8", "rw")
            fs.readFile(file[0], "utf8", (err, data) => {
                if (err) throw err;
                if (ext.match(/bin/g) || lang.match(/x-/g)) {
                    //workaround para ficheiros com extenção x-...
                    changeModel(fileExtention[0], data, tab)
                } else if (lang.match(/mp2t/g)) {
                    //workaround para ficheiros typescript
                    changeModel("javascript", data, tab)
                    setLang("typescript")
                } else {
                    changeModel(lang, data, tab)
                }
            })
            if (fileTabExists(file[0]) === true) {
                aticveTab(tab)
            } else {
                createFileTab(fileName.length > 14 ? fileName.slice(0, 14) : fileName, fileExtention[0], file)
                createSidebarFileTab(fileName.length > 14 ? fileName.slice(0, 14) : fileName, fileExtention[0], file)
            }
        }

        if (files) {
            loadFile(files)
        }

        ipc.on("load-file", function (sender, file, tab) {
            loadFile(file, tab)
        })

        win.MODES = (function () {
            var modesIds = monaco.languages.getLanguages()
                .map(function (lang) {
                    return lang.id;
                });
            modesIds.sort();
            return modesIds.map(function (modeId) {
                return {
                    modeId: modeId
                };
            });
        })

        win.MODES().map(function (item) {
            select.appendChild(document.createElement("option"))
            select.lastChild.value = item.modeId
            select.lastChild.innerHTML = item.modeId
        })

        select.onchange = function () {
            changeModel(select.options[select.selectedIndex].value)
            resetApp.editor()
        }

        win.editor.onKeyDown(save, event)

        win.editor.onDidChangeModelContent(
            function (e) {
                if (e.isUndoing === false) {
                    controlObject.model[controlObject.activeTab.lastElementChild.getAttribute("title")].pasteCount += 1
                    if (controlObject.ativeTabNotSaved.state === false && controlObject.model[controlObject.activeTab.lastElementChild
                        .getAttribute("title")].pasteCountState === false) {
                        ativeTabNotSaved()
                        controlObject.model[controlObject.activeTab.lastElementChild.getAttribute("title")].pasteCountState = true
                        controlObject.ativeTabNotSaved.state = true
                    }
                }
            }
        )
        
        win.languages = monaco.languages
        win.monaco = monaco
        win.changeModel = changeModel
        win.loadFile = loadFile
        win.firstModel = firstModel
    });

    return win
}
/* win.editor.addAction({
            id: "lang_json",
            label: "lang to json",
            run: () => {
                monaco.editor.setModelLanguage(editor.getModel(), "json");
                //console.log("i've done my job")
            }
        })*/
/////////////////////////////////////library\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
var init = {}, i
function startEditor(files) {
    var path1 = window.location.pathname.split("/")
    path1[path1.length - 1] = ""
    var fpath = path.join(path1.join("/"), "js/files.json")

    var r = jf.readFileSync(fpath, "utf8")
    r = {}
    jf.writeFileSync(fpath, r)
    init.win = control("javascript", "", "container", files)
}
