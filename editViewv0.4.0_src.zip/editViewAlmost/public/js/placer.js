

'use strict'
//instaciamento dos elementos principais
const tabopen = document.querySelector(".tabopen"),
    topclose = document.querySelector(".topclose"),
    tabopentab = document.querySelector(".tabopentab"),
    cleanTabs = document.querySelector(".cleanTabs"),
    color = document.querySelector(".color"),
    cleanTabsSideBar = document.querySelector(".cleanTabsSideBar"),
    sideCleanTabs = document.querySelector(".sideCleanTabs"),
    themes = document.querySelector(".themes"),
    resizable = document.querySelector(".resizable"),
    dragover = document.querySelector(".dragover"),
    toggleCreate = document.querySelector(".toggleCreate")
//path dos ficheiros json
var path1 = window.location.pathname.split("/")
path1[path1.length - 1] = ""
const fpath = path.join(path1.join("/"), "js/files.json")
const fpath1 = path.join(path1.join("/"), "js/folder.json")

//funcção que lê as Json files
function readJsonFile(type, obj, par) {
    var r = jf.readFileSync(fpath, "utf8")
    var r2 = jf.readFileSync(fpath1, "utf8")
    return type === "file" ? r[obj][par] : r2[obj][par]
}
//funcção que escreve nas json files
function writeJsonFile(type, obj, par, value) {
    var r = jf.readFileSync(fpath, "utf8")
    var r2 = jf.readFileSync(fpath1, "utf8")
    if (par !== undefined) {
        type === "file" ? r[obj][par] = value : r2[obj][par] = value
        type === "file" ? jf.writeFileSync(fpath, r) : jf.writeFileSync(fpath1, r2)
    } else {
        type === "file" ? jf.writeFileSync(fpath, obj) : jf.writeFileSync(fpath1, obj)
    }
}
//função que limpa as json files
function cleanJsonFile(type) {
    var r = jf.readFileSync(fpath, "utf8")
    var r2 = jf.readFileSync(fpath1, "utf8")
    var deleteparFiles = () => {
        for (var par in r["files"]) {
            delete r["files"][par]
            delete r["filetabStatus"][par]
        }
    }
    var arr = Object.keys(r2["project"])
    type === "file" ? deleteparFiles() : delete r2["project"][arr[0]]
    type === "file" ? jf.writeFileSync(fpath, r) : jf.writeFileSync(fpath1, r2)
}
//função que guarda o nome e a path dos ficheiros carregados num ficheiro JSON
function tabs(files, patho) {
    files = files.length > 9 ? files.slice(0, 9) : files
    writeJsonFile("file", "files", files, patho)
}
topclose.children[0].lastElementChild.children[0].children[0].onclick = evt => {
    topclose.children[0].lastElementChild.children[0].children[0].nextElementSibling.classList.toggle("openDroDown")
}
// objecto de controlo
//será passdo para json assim que tiver toudos os elementos necessários
//a apicação passará a criar todo o GUI ao iniciar
var controlObject = {
    tabCount: 0,
    activeTab: "",
    tabNotSaved: false,
    ativeTabNotSaved: {
        state: false,
        element: "",
    },
    direlem: {},
    tabSize: 1,
    wordCount: 0,
    enterCount: 0,
    model: {}
}
//tabopentab\\relativa à sidebar cujo tamanho serve de referencia ao redimencionar a aplicação
tabopentab.style.width = "178px"
//variaveis de reidmencionamento da aplicação
//para ser revisto\\ 
var stdsize2 = 62, stdsize3 = 31,
    size = document.documentElement.clientWidth - parseInt(tabopentab.style.width) + "px",
    size2 = document.documentElement.clientWidth - (document.documentElement.clientWidth - parseInt(tabopentab.style.width)) + "px",
    size3 = window.innerHeight - stdsize2 + "px",
    size4 = window.innerHeight - stdsize3 + "px"

//dimenção de inicio
//para ser revisto\\ 
color.style.height = stdsize3
tabopen.style.width = size
topclose.style.width = size
tabopen.style.height = size3
tabopentab.style.height = size4
tabopentab.children[2].style.left = "171px"
tabopentab.firstElementChild.style.left = "197px"
dragover.style.width = "178px"
color.lastElementChild.style.left = window.innerWidth - 252 + "px"
topclose.style.height = window.innerHeight - stdsize3 + "px"
resizable.style.height = size3

//função que contém metodos par redimencionar a app o editor e a sidebar
//para ser revisto\\ 
function resizeApp() {
    //redimencina só a aplicação
    function app() {
        tabopen.style.width = document.documentElement.clientWidth - parseInt(tabopentab.style.width) + "px"
        topclose.style.width = document.documentElement.clientWidth - parseInt(tabopentab.style.width) + "px"
        if (parseInt(color.style.height) === 20) {
            color.lastElementChild.style.top = "15px"
            tabopen.style.height = window.innerHeight - (parseInt(color.style.height) + (stdsize2 - 40)) + "px"
            resizable.style.height = window.innerHeight - (parseInt(color.style.height) + (stdsize2 - 40)) + "px"
        } else {
            tabopen.style.height = window.innerHeight - (parseInt(color.style.height) + (stdsize2 - stdsize3)) + "px"
            resizable.style.height = window.innerHeight - (parseInt(color.style.height) + (stdsize2 - stdsize3)) + "px"
            color.lastElementChild.style.top = "33px"
        }
        color.lastElementChild.style.left = window.innerWidth - 252 + "px"
        tabopentab.style.height = window.innerHeight - stdsize3 + "px"
        topclose.style.height = window.innerHeight - stdsize3 + "px"
    }
    //redimencina o editor usa o seu próprio método "Monaco"
    function editor() {
        if (tabopen.firstElementChild) {
            init.win.editor.layout()
        }
    }
    //reletivo à sidebar// retira o recoloca os elemtos conforme esteja aberta ou fechada
    function arrangeRest() {
        tabopentab.children[0].firstElementChild.classList.toggle("togglePosBtnClosed")
        tabopentab.classList.toggle("tabopentabClosed")
        tabopentab.children[1].classList.toggle("dropFiles")
        app()
        editor()
    }
    //reletivo à sidebar// redimencina a sidebar para o estado fechado
    //não pode ser com toggle classes, tem de ter as dimenções disponiveis 
    //para manipulação ao arrastar
    function resizeToButton() {
        tabopentab.style.width = "40px"
        tabopentab.children[2].style.display = "none"
        tabopentab.firstElementChild.style.left = "45px"
        dragover.style.width = "40px"
        //color.lastElementChild.style.left = window.innerWidth - (sideCleanTabs.clientWidth - 10) + "px"
    }
    //reletivo à sidebar// redimencina a sidebar para o estado aberto
    //não pode ser com toggle classes, tem de ter as dimenções disponiveis 
    //para manipulação ao arrastar
    function putback() {
        tabopentab.style.width = "178px"
        dragover.style.width = "178px"
        tabopentab.children[2].style.left = "171px"
        tabopentab.children[2].style.display = "block"
        tabopentab.children[2].style.background = "transparent"
        tabopentab.firstElementChild.style.left = "193px"
    }

    //retorna as funções num objecto que será instaciado numa variável
    return {
        all: () => {
            app()
            editor()
        },
        app: app,
        editor: editor,
        arrangeRest: arrangeRest,
        resizeToButton: resizeToButton,
        // containerHeight: containerHeight,
        putback: putback,
        textActivity: false
    }
}

//instanciamento da função reziseApp que retorna os métodos de redimencionamento
const resetApp = resizeApp()
// ao redimencionar ajusta editor e app
window.onresize = e => {
    resetApp.all()
}

//////////////////funciona////////
sideCleanTabs.firstElementChild.onclick = closeFileTab
sideCleanTabs.children[1].onclick = item => {
    themes.classList.toggle("openDroDown")
}
//função que fecha a file tab
function closeFileTab(event) {
    event.srcElement.parentElement.previousElementSibling.style.display = "none"
    event.srcElement.parentElement.parentElement.style.height = "20px"
    event.srcElement.parentElement.style.height = "20px"
    event.srcElement.parentElement.style.marginTop = "-5px"
    event.srcElement.style.height = "15px"
    event.srcElement.style.zIndex = 1
    resetApp.all()
    event.srcElement.onclick = {}
    event.srcElement.onclick = openFileTab//"fucnção que volta a abrir"
}
//função que fecha a file tab
function openFileTab(event) {
    event.srcElement.parentElement.previousElementSibling.style.display = "block"
    event.srcElement.parentElement.parentElement.style.height = "31px"
    event.srcElement.parentElement.style.height = "inherit"
    event.srcElement.parentElement.style.marginTop = "0px"
    event.srcElement.style.height = ""
    event.srcElement.style.zIndex = 0
    resetApp.all()
    event.srcElement.onclick = {}
    event.srcElement.onclick = closeFileTab//"fucnção que volta a fechar"
}
//

//\\\\\\\\\\\\\\\\

//funcção toggleSidebar 
tabopentab.firstElementChild.addEventListener("click", (e) => {
    if (parseInt(tabopentab.style.width) > 40) {
        resetApp.resizeToButton()
    } else {
        resetApp.putback()
    }
    resetApp.arrangeRest()
})
//listner de funcção para mostrar a barra de redimencionar a sidebar
tabopentab.children[2].setAttribute("onmouseover", "showHide(this)")
//fucnção que mostra e esconde a barra de redimencionar a sidebar
//mostra e esconde passados 5 segundos
function showHide(e) {
    e.style.background = 'rgba(128, 128, 128, 0.2)'
    setTimeout(() => e.style.background = 'transparent', 5000)
}
//listner para redimencionar a sidebar
//tem limite de expanção e encolhimento
//recollhe para um dos estados default após passar o limite imposto
tabopentab.children[2].onmousedown = e => {
    e.preventDefault()
    //console.log(e)    
    tabopentab.onmousemove = evt => {
        e.preventDefault()
        if (parseInt(tabopentab.style.width) > 155 && parseInt(tabopentab.style.width) < 360) {
            //para efectuar este processo os elementos em questão não podem ter as dimenções ou margens em classes css
            //como consta nos métodos resizeToButton e putback
            e.srcElement.style.left = parseInt(e.srcElement.style.left) + evt.movementX + "px"
            tabopentab.style.width = parseInt(tabopentab.style.width) + evt.movementX + "px"
            tabopentab.firstElementChild.style.left = parseInt(tabopentab.firstElementChild.style.left) + evt.movementX + "px"
        }
        //recollhe para um dos estados default após passar o limite imposto
        // ao espandir vai alterando o background de amarelo para laranja e por fim vermelho até fechar automaticamente
        //o encolher não tem alternacia de background, a não ser quando vem de expandido, qua indica + v - a posição inicial
        if (parseInt(tabopentab.style.width) <= 155 && parseInt(tabopentab.style.width) >= 145) {
            tabopentab.firstElementChild.click()
        }
        if (parseInt(tabopentab.style.width) >= 320) {
            e.srcElement.style.background = "#ffff00"
        }
        if (parseInt(tabopentab.style.width) >= 330) {
            e.srcElement.style.background = "#e24e0d"
        }
        if (parseInt(tabopentab.style.width) >= 340) {
            e.srcElement.style.background = "#d22929"
        }
        if (parseInt(tabopentab.style.width) >= 350 && parseInt(tabopentab.style.width) <= 360) {
            resetApp.putback()
        }
        resetApp.all()
    }
}
/*  secção tabs de ficheiors  */
//função que cria as tabs com o nome dos ficheiros
function createFileTab(file, extention, patho) {
    var div = document.createElement("DIV");
    cleanTabs.appendChild(div)
    div.setAttribute("tabindex", controlObject.tabCount)
    div.setAttribute("label", file)
    div.className = "fileTab  text-center"
    div.style.left = controlObject.tabSize + "px"
    controlObject.tabSize += 131;
    controlObject
        .ativeTab = controlObject.tabCount
    controlObject
        .tabCount += 1
    div.appendChild(document.createElement("div"))
    div.lastElementChild
        .className = "fileTabClolseButton"
    div.lastElementChild
        .style.color = "white"
    div.lastElementChild
        .innerHTML = "x"
    div.appendChild(document.createElement("div"))
    div.lastElementChild
        .style.color = "white"
    div.lastElementChild
        .className = "fileTabExtentionButton"
    div.lastElementChild.setAttribute("label", extention)
    div.lastElementChild
        .innerHTML = imgObj[extention] ? `<img style="width: 16px" src="${imgObj[extention]}"/>` : extention.length > 3 ? extention.slice(0, 3) : extention
    div.appendChild(document.createElement("div"))
    div.lastElementChild
        .classList.add("box")
    div.lastElementChild
        .setAttribute("title", patho)
    div.lastElementChild
        .innerHTML = file.length > 9 ? file.slice(0, 9) : file
    aticveTab(div)
    tabsListenToThis(div);
    tabs(file, patho)
    setTimeout(() => {
        controlObject.model[patho] = {}
        controlObject.model[patho].lineCount = init.win.editor.model.getLineCount()
        controlObject.model[patho].wordCount = 0
        controlObject.model[patho].pasteCountState = false
        controlObject.model[patho].pasteCount = 0
    }, 250)
}
//O nome desta função pouco tem a ver com o que faz\
//onkeypress event function que é chamada ao se pressionar numa tecla no editor
//o listner é criado na função controll em main.js\/public/js#152
function save(e) {
    if (e.ctrlKey === false
        && event.code.indexOf("Arrow") === -1
        && event.code.indexOf("Shift") === -1
        && event.code.match(/^F\d$|^F\d\d$/) === -1
        && event.code.indexOf("Meta") === -1
        && event.key !== "CapsLock"
        && event.key !== "Tab"
        && event.key !== "Alt"
        && event.key !== "Backspace"
        && event.key !== "Enter"
        && event.key !== "Delete") {
        controlObject.model[controlObject.activeTab.lastElementChild.getAttribute("title")].wordCount += 1
        controlObject.ativeTabNotSaved.state = true
        if (controlObject.activeTab.lastElementChild.classList.contains("activeNotSaved") === false ||
            controlObject.model[controlObject.activeTab.lastElementChild.getAttribute("title")].wordCount === 0) {
            ativeTabNotSaved()
            //activeNotSavedSideTabFile(controlObject.activeTab.lastElementChild.getAttribute("title"))
        }
    }
    var wordCount = controlObject.model[controlObject.activeTab.lastElementChild.getAttribute("title")].wordCount >= 0 ?
        controlObject.model[controlObject.activeTab.lastElementChild.getAttribute("title")].wordCount : ""
    var lineCount = controlObject.model[controlObject.activeTab.lastElementChild.getAttribute("title")].lineCount
    if (event.key === "Enter") {
        console.log(controlObject.ativeTabNotSaved.state === false)
        if (controlObject.ativeTabNotSaved.state === false) {
            ativeTabNotSaved()
            controlObject.ativeTabNotSaved.state = true
        }
    }
    //controlo Backspace & Delete\\
    //quando wordCount é igual a 0 passa para (não alterado)
    if (event.key === "Backspace" || event.key === "Delete") {
        let count = init.win.editor.model.getLineCount()
        if (controlObject.ativeTabNotSaved.state === false) {
            ativeTabNotSaved()
            controlObject.ativeTabNotSaved.state = true
        } else if (count === lineCount && wordCount === 0) {
            ativeTabNotSaved()
        }
    }

    if (e.ctrlKey === true) {
        // ctrl-z deverá desligar o estado notSaved quando o ficheiro volta ao estado inicial
        //o Monaco tem métodos que poderão simplificar esta operação//será retificado\\
        if (event.key === "z" && controlObject.ativeTabNotSaved.state === true) {
            let count = init.win.editor.model.getLineCount()
            if (controlObject.model[controlObject.activeTab.lastElementChild.getAttribute("title")].pasteCountState === false) {
                if (wordCount === 0 && count === lineCount) {
                    controlObject.model[controlObject.activeTab.lastElementChild.getAttribute("title")].wordCount = 0
                    ativeTabNotSaved()
                    //activeNotSavedSideTabFile(controlObject.activeTab.lastElementChild.getAttribute("title"))
                    controlObject.ativeTabNotSaved.state = false
                }
                if (count === lineCount && wordCount > 0) {
                    controlObject.model[controlObject.activeTab.lastElementChild.getAttribute("title")].wordCount = 0
                    ativeTabNotSaved()
                    controlObject.ativeTabNotSaved.state = false
                }

            } else {
                let ypasteCount = controlObject.model[controlObject.activeTab.lastElementChild.getAttribute("title")].pasteCount
                //ypasteCount -= 1
                pasteOut(ypasteCount, count, lineCount)
            }
        }
    }
}
//função que controla o estado notSaved apos pasting
function pasteOut(ypasteCount, count, lineCount) {
    if (controlObject.model[controlObject.activeTab.lastElementChild.getAttribute("title")].pasteCountState === true) {
        ypasteCount -= 1
        controlObject.model[controlObject.activeTab.lastElementChild.getAttribute("title")].pasteCount = ypasteCount
        if (controlObject.model[controlObject.activeTab.lastElementChild.getAttribute("title")].pasteCount === 0 && count === lineCount) {
            ativeTabNotSaved()
            controlObject.ativeTabNotSaved.state = false
            controlObject.model[controlObject.activeTab.lastElementChild.getAttribute("title")].pasteCountState = false
        }
    }
}

//função que adiciona listners às file tabs
function tabsListenToThis(div) {
    div.children[2].addEventListener("click", e => {
        e.stopPropagation()
        init.win.loadFile(e.srcElement.getAttribute("title").split(), div)
        checkActiveSideFiles()
        activeSideTabFile(e.srcElement.getAttribute("title"))
    })
    div.setAttribute("onmouseover", `xButton(event, this)`)
}
//função para adicionar o listner ao botão que fecha as file tabs
function xButton(e, elem) {
    var element = elem.firstElementChild
    var parent = elem
    element.style.display = "block"
    //função que controla o fecho da file tab
    //remove a file tab e a active file extention sidebar tab
    element.onclick = function () {
        closeTabs(parent)
    }
    XButtonLeave([tabopen, tabopentab, sideCleanTabs], e, element)
}
//funcção que remove a existencia de um ficheiro na aplicação
//invocada por XButton
function closeTabs(parent, dontLoad) {
    var extention = parent.children[1].getAttribute("label")
    deleteSideTab(extention, parent.lastElementChild.getAttribute("title"))
    cleanUpTabs(parent.style.left)
    var r = jf.readFileSync(fpath, "utf8")
    delete r["files"][parent.lastElementChild.innerHTML]
    if (r["filetabStatus"]["tabActive"]) delete r["filetabStatus"]["tabActive"]
    jf.writeFileSync(fpath, r)
    controlObject.tabCount -= 1
    parent.parentElement.removeChild(parent)
    controlObject.tabSize -= 131
    if (cleanTabs.childElementCount < 1) {
        var model = init.win.editor.getModel()
        model.dispose(parent.style.left)
        //init.win.firstModel("javascript", "") 
    } else {
        init.win.loadFile(cleanTabs.children[cleanTabs.childElementCount - 1].lastChild
            .getAttribute("title").split(), cleanTabs.children[cleanTabs.childElementCount - 1])
    }
}

//função que esconde o botão de fechar tab ao fazer hover em [tabopen, tabopentab, sideCleanTabs]
function XButtonLeave(leaveNode, evt, element) {
    evt.stopPropagation()
    leaveNode.map(item => {
        item.onmouseover = () => element.style.display = "none"
    })
}
//override para soltar o rato
window.onmouseup = ev => {
    ev.preventDefault()
    tabopentab.onmousemove = () => { }
}
//função que coloca as tabs que se situam num index acima da tab removida
// e coloca-as 159px menos, relativamente à margem inicial de cada uma
function cleanUpTabs(margin) {
    for (var i = 0; i < cleanTabs.childElementCount; i++) {
        if (parseInt(cleanTabs.children[i].style.left) > parseInt(margin)) {
            cleanTabs.children[i].style.left = parseInt(cleanTabs.children[i].style.left) - 131 + "px"
        }
    }
}
//função que muda o estilo da tab para activo
function aticveTab(tab, notbox) {
    if (!notbox) {
        checkActive()
        controlObject.activeTab = tab
        writeJsonFile("file", "filetabStatus", "tabActive", tab.lastElementChild.getAttribute("title"))
        checkActive()
        //.children[2].getAttribute("title")
    } else {
        tab.classList.toggle("tabActive")
        tab.classList.toggle("activeBbox")
    }
}
//função que verifica se uma tab está activa, se estiver desactiva-a
function checkActive() {
    var i, j
    if (controlObject.activeTab) {
        controlObject.activeTab.classList.toggle("tabActive")
        controlObject.activeTab.lastElementChild.classList.toggle("activeBbox")
    }
}
//função que verifica se o ficheiro carregado já existe
function fileTabExists(filename) {
    var i
    for (i = 0; i < cleanTabs.childElementCount; i++) {
        if (cleanTabs.children[i].lastElementChild.getAttribute("title") === filename) {
            return true
        }
    }
}
function ativeTabNotSaved(ativeTab) {
    if (controlObject.activeTab) {
        //controlObject.activeTab.lastElementChild.classList.toggle("activeNotSaved")
        //activeNotSavedSideTabFile(controlObject.activeTab.lastElementChild.getAttribute("title"))
        if (controlObject.ativeTabNotSaved.state === true) {
            //controlObject.activeTab.lastElementChild.classList.toggle("activeNotSaved")
            controlObject.activeTab.lastElementChild.classList.toggle("activeNotSaved")
            activeNotSavedSideTabFile(controlObject.activeTab.lastElementChild.getAttribute("title"))
            //controlObject.ativeTabNotSaved.state = true
            controlObject.ativeTabNotSaved.element = controlObject.activeTab.lastElementChild
        } else {
            controlObject.activeTab.lastElementChild.classList.toggle("activeNotSaved")
            activeNotSavedSideTabFile(controlObject.activeTab.lastElementChild.getAttribute("title"))
            controlObject.ativeTabNotSaved.state = false
            controlObject.ativeTabNotSaved.element = ""
        }
    }
}

/*  secção sidebar  */
//função que remove o elemento da sidebar com o nome do ficheiro que foi removido da area de filetabs
function deleteSideTab(extention, file) {
    var ele = document.querySelectorAll("ul[class]"), i, j
    for (i = 0; i < ele.length; i++) {
        if (ele[i].classList.contains(extention)) {
            for (j = 0; j < ele[i].childElementCount; j++) {
                //t fileNames = file.length > 9 ? file.slice(0, 9) : file
                console.log(ele[i].children[j].getAttribute("title"))
                if (ele[i].children[j].getAttribute("title") === file) {
                    ele[i].removeChild(ele[i].children[j])
                }
                if (ele[i].childElementCount < 1) {
                    ele[i].parentNode.parentNode.removeChild(ele[i].parentNode)
                }
            }
        }
    }
}
// variaveis para adicionar os listners aos sidebar tabs que abrem os containers de ficheiros abertos e directorios ou nome do projecto
var r = cleanTabsSideBar.children[0], r2 = cleanTabsSideBar.children[1]
//listener que faz o toggle à area de ficheiros abertos
r.firstElementChild.addEventListener("click", event => {
    event.stopPropagation()
    for (var i = 0; i < r.childElementCount; i++) {
        r.children[i].classList.toggle("openDroDown")
    }
})
//listener que faz o toggle à area de directórios ou nome do projecto
r2.firstElementChild.children[0].addEventListener("click", event => {
    r2.children[1].classList.toggle("openDroDown")
})
r2.firstElementChild.children[1].addEventListener("click", event => {

    event.srcElement.parentElement.parentElement.children[2].classList.toggle("openDroDown")

})
r2.firstElementChild.children[2].children[0].addEventListener("click", event => {
    event.srcElement.contentEditable = true
    //esta função pertence à biblioteca cursorEditable
    inputHandler(event, event.srcElement.innerHTML, "main", r2.firstElementChild.children[0])
})
const activeT = readJsonFile("file", "filetabStatus", "tabActive")
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//funcção que cria a label com o nome do ficheiro, na secção "extenção" de ficheiros abertos
function createSidebarFileTab(filename, extention, patho) {
    var div = document.createElement("DIV"),
        div2 = document.createElement("DIV"),
        ul = document.createElement("UL"),
        li = document.createElement("LI"),
        i = 0, evaluate = false, count,
        r = document.querySelectorAll("ul[class]")
    li.className = "marg btn-default text-left col-xs-12 cursor"
    div2.style.marginLeft = "-18px"
    div2.style.width = "122px"
    li.setAttribute("title", patho)
    let fileName = filename.length > 9 ? filename.slice(0, 9) : filename
    // li.setAttribute("title", filename)
    //verifica se a "extenção" já existe - retorna true para 'evaluate' e o index da "extenção" para 'count'
    for (i = 0; i < r.length; i++) {
        if (r[i].classList.contains(extention) === true) {
            evaluate = true
            count = i
        }
    }
    //se 'evaluate' true apende à "extenção" caso contraio cria nova e apende 
    if (evaluate === true) {
        r[count].appendChild(li)
        let fileNames = filename.length > 9 ? filename.slice(0, 9) : filename
        li.innerHTML = fileNames
        li.setAttribute("tabindex", controlObject.tabCount)
        li.addEventListener("click", (e) => {
            init.win.loadFile(li.getAttribute("title").split(), cleanTabs.children[li.getAttribute("tabindex") - 1])
            checkActiveSideFiles(e.srcElement.parentElement.parentElement)
            aticveTab(li, 1)
        })
    } else {
        div.className = "col-xs-12 subFolder dropFiles"
        div.style.marginLeft = "16px"
        div2.className = "col-xs-12 label label-custom cursor"
        div2.innerHTML = extention
        div2.addEventListener("click", event => {
            aticveTab(div2, 1)
            ul.classList.toggle("openDroDown")
        })
        ul.className = "dropFiles " + extention
        cleanTabsSideBar.children[0].appendChild(div)
        div.appendChild(div2)
        div.appendChild(ul)
        ul.appendChild(li)
        let fileNames = filename.length > 9 ? filename.slice(0, 9) : filename
        li.innerHTML = fileNames
        li.setAttribute("tabindex", controlObject.tabCount)
        li.addEventListener("click", (e) => {
            init.win.loadFile(li.getAttribute("title").split(), cleanTabs.children[li.getAttribute("tabindex") - 1])
            checkActiveSideFiles()
            aticveTab(li, 1)
        })
    }
    div.classList.toggle("openDroDown")
    checkActiveSideFiles()
    readJsonFile("file", "filetabStatus", "tabActive")
    activeSideTabFile(activeT)
}
//fucnção que retorna um array de elementos
//da area de ficheiros abertos para serem avaliados
//afim de serem desactivados 
//retorna a div com a label da "extenção"
function putElemenInArray(element) {
    var arrelem = Array.from(element)
    return arrelem.map(item => {
        for (i = 0; i < item.childElementCount; i++) {
            return item.children[i] !== undefined ? item.children[i] : ""
        }
    })
}

//função que verifica se existem elementos activados na àre de ficheiros abertos e desactiva-os
function checkActiveSideFiles() {
    var i, j
    var asd = putElemenInArray(cleanTabsSideBar.firstElementChild.children)
    for (i = 1; i < asd.length; i++) {
        for (j = 0; j < asd[i].nextElementSibling.children.length; j++) {
            if (asd[i].nextElementSibling.children[j].classList.contains("tabActive") === true) {
                asd[i].nextElementSibling.children[j].classList.toggle("tabActive")
                asd[i].nextElementSibling.children[j].classList.toggle("activeBbox")
            }
        }
    }
}
//fucnçẽs que activam o elemento da àrea de ficheiros abertos referente ao ficheiro activo
function activeSideTabFile(path) {
    var i, j
    var asd = putElemenInArray(cleanTabsSideBar.firstElementChild.children)
    for (i = 1; i < asd.length; i++) {
        for (j = 0; j < asd[i].nextElementSibling.children.length; j++) {
            if (asd[i].nextElementSibling.children[j].getAttribute("title") === path) {
                asd[i].nextElementSibling.children[j].classList.toggle("tabActive")
                asd[i].nextElementSibling.children[j].classList.toggle("activeBbox")
            }
        }
    }
}
//para ficheiros não guardados
function activeNotSavedSideTabFile(path) {
    var i, j
    var asd = putElemenInArray(cleanTabsSideBar.firstElementChild.children)
    for (i = 1; i < asd.length; i++) {
        for (j = 0; j < asd[i].nextElementSibling.children.length; j++) {
            if (asd[i].nextElementSibling.children[j].getAttribute("title") === path) {
                asd[i].nextElementSibling.children[j].classList.toggle("activeNotSaved")
            }
        }
    }
}

//fucnção que cria as pastas e os ficheiros carregados para a àrea de directoórios 
function createSidebarDirTab(patho, dir, elem, erase) {
    const element = elem === undefined ? r2.lastElementChild : elem
    //'erase' limpa a area de directórios limpa o ficheiro JSON e cria nova entrada
    //regista a path do projecto
    erase === "keep" ? r2.lastElementChild.innerHTML = "" : ""
    if (erase === "erase") {
        r2.lastElementChild.innerHTML = ""
        cleanJsonFile("folder")
        cleanJsonFile("file")
        writeJsonFile("folder", "project", "path", patho)
        writeJsonFile("folder", "project", "dir", "folder")
        while (cleanTabs.childElementCount) {
            closeTabs(cleanTabs.lastElementChild, 1)
        }
        cleanTabs.childElementCount > 0 ? closeTabs(cleanTabs.lastElementChild) : ""
    }
    //'dir'-'folder' refere-se ao directório raiz que fica em destaque na label da area de directórios
    // os restantes directorios serão 'dir'-'subfolder'
    if (dir === "folder") {
        let filename = patho.split("/").pop()
        r2.firstElementChild.children[0].innerHTML = filename.length > 14 ? filename.slice(0, 14) : filename
        r2.firstElementChild.children[0].setAttribute("title", patho)
        r2.firstElementChild.classList.add(dir)
    }
    //coloca o directório
    asd(patho, elem, function (a, stat) {
        //dentro do callback\\
        //cria os elementos depois de ser verificado e é ficheior ou directorio "stat"
        var divFolder = document.createElement("DIV"),
            divLabel = document.createElement("DIV"),
            divDropFiles = document.createElement("DIV")
        //adicoina classes e atributos
        divFolder.className = "subFolder"
        divLabel.className = "col-xs-10 label label-custom cursor marg2"
        divDropFiles.className = "dropFiles"
        divDropFiles.setAttribute("title", path.join(patho, a))
        //operações caso seja directorio "stat"     
        if (stat === "dir") {
            element.appendChild(divFolder)
            divLabel.innerHTML = `<section class="dirLabelText">${a.length > 11 ? a.slice(0, 11) : a}</section> ${createButton}`
            divLabel.firstElementChild.addEventListener("click", function (e) {
                e.stopPropagation()
                if (e.srcElement.parentElement.nextElementSibling.childElementCount === 0) {
                    createSidebarDirTab(path.join(patho, a), "subFolder", divDropFiles)
                }
                divDropFiles.classList.toggle("openDroDown")
            })
            //listener para abir o directorio
            divLabel.children[1].addEventListener("click", event => {
                event.srcElement.parentElement.parentElement.classList.toggle("openCreate")
                event.srcElement.parentElement.parentElement.classList.toggle("label-custom")
                event.srcElement.parentElement.parentElement.classList.toggle("noBackground")
                event.srcElement.parentElement.parentElement.children[2].classList.toggle("openDroDown")
            })
            //listner par a criação de ficheiros ou directorios
            divLabel.children[2].addEventListener("click", event => {
                event.srcElement.contentEditable = true
                //esta função pertence à biblioteca cursorEditable
                inputHandler(event, event.srcElement.innerHTML, "subFolder", divDropFiles)
            })
            divFolder.ondblclick = () => {
                event.srcElement.contentEditable = true
                if (event.srcElement.parentElement.classList.contains("subFolder") === true) {
                    inputHandler(event, "renameFolder", "subFolder", element)
                } else if (event.srcElement.parentElement.previousElementSibling.classList.contains("folder") === true) {
                    inputHandler(event, "renameFolder", "main", element)
                }
            }
            divFolder.appendChild(divLabel)
            divFolder.appendChild(divDropFiles)
            controlObject.direlem[path.join(patho)] = divFolder.lastElementChild
        }
    })
    //coloca os ficheiros do directorio
    setTimeout(() => {
        asd(patho, elem, (a, stat, elem) => {
            var divFile = document.createElement("DIV"),
                fileName = document.createElement("SECTION")
            divFile.className = "col-xs-12 cursor"
            fileName.className = "btn btn-default col-xs-12 marg3"
            fileName.innerHTML = a.length > 11 ? a.slice(0, 11) : a
            if (stat === "file") {
                element.appendChild(divFile)
                fileName.setAttribute("title", path.join(patho, a))
                divFile.appendChild(fileName)
                //listner para abir ficheiros
                fileName.addEventListener("click", e => {
                    event.srcElement.contentEditable = false
                    fileName.innerHTML = a.length > 11 ? a.slice(0, 11) : a
                    msgObj.msg.length > 0 ? msgObj.msg = "" : ""
                    e.stopPropagation()
                    //se já existir o ficheiro muda a aparencia por 500 mls
                    //caso contrário carrega o ficheiro e grava a entrada do ficheiro o estado                    
                    if (fileTabExists(path.join(patho, a)) !== true) {
                        init.win.loadFile(path.join(patho, a).split())
                        setTimeout(() => {
                            checkActiveSideFiles()
                            activeSideTabFile(readJsonFile("file", "filetabStatus", "tabActive"))
                        }, 250)
                    } else {
                        aticveTab(divFile, 1)
                        setTimeout(() => {
                            divFile.classList.contains("activeBbox") ? aticveTab(divFile, 1) : ""
                        }, 500)
                    }
                })
                var i = { c: 0 }
                divFile.ondblclick = (e) => {
                    event.srcElement.contentEditable = true
                    if (event.srcElement.parentElement.parentElement.parentElement.classList.contains("subFolder") === true) {
                        i.c += 1
                        inputHandler(event, "renameFile", "subFolder", element)
                    } else if (event.srcElement.parentElement.parentElement.previousElementSibling.classList.contains("folder") === true) {
                        inputHandler(event, "renameFile", "main", element)
                    }
                }
            }
            controlObject.direlem[path.join(patho)] = element
        })
    }, 125)
    if (r2.children[1].classList.toggle("openDroDown") === false) {
        r2.children[1].classList.toggle("openDroDown")
    }
}
//funcção que verifica se o conteudo de um diretorio é fichiro ou diretorio
//faz callback em ambos os casos, em caso de ficheiro envia o elemento correspondento ao directorio de volta 
//este processo será rectifado\\
function asd(dir, elem, call) {
    dir !== undefined ? fs.readdir(dir, (err, files) => {
        if (err) {
            throw new Error(err);
        }
        files.filter(function (file) {
            fs.statSync(path.join(dir, file)).isFile() ? call(file, "file", elem) : call(file, "dir")
        })
    }) : init.win.changeModel("markdown", `# EditView

**Experimental code editor**

This is a minimal Electron application based on Code Visual Studio

**Use this app [on your own reponsability]**

- Drag folder into sideBar and drop wen it's black




!!!May the force be with you!!!

`, "markdown")
}
//ao clicar num ficheiro na area de directŕios a funcção 'init.win.loadFile' pode levar um elemento relativo à filetab aberta
function getElementFromPath(path) {
    var arr = Array.from(cleanTabs.children)
    var asd = arr.map(function (item) {
        return item.children
    })
    for (var i = 0; i < asd.length; i++) {
        var tar = Array.from(asd[i])
        if (tar[2].getAttribute("title").toString() === path) {
            return cleanTabs.children[i]
        }
    }
}
//objecto que contém a path das imágens das estenções nas filetab
var imgObj = {
    bat: "assets/extetionImg/bat.png",
    cpp: "assets/extetionImg/cpp.png",
    csharp: "assets/extetionImg/csharp.png",
    css: "assets/extetionImg/css.png",
    dockerfile: "assets/extetionImg/dockerfile.png",
    fsharp: "assets/extetionImg/fsharp.png",
    go: "assets/extetionImg/go.png",
    html: "assets/extetionImg/html.png",
    ini: "assets/extetionImg/ini.png",
    java: "assets/extetionImg/java.jpg",
    js: "assets/extetionImg/javascript.png",
    json: "assets/extetionImg/json.png",
    less: "assets/extetionImg/less.jpg",
    lua: "assets/extetionImg/lua.png",
    markdown: "assets/extetionImg/md.png",
    objective: "assets/extetionImg/objective-c.png",
    php: "assets/extetionImg/bat.png",
    plaintext: "assets/extetionImg/plaintext.png",
    powershell: "assets/extetionImg/powershell.png",
    py: "assets/extetionImg/python.jpg",
    r: "assets/extetionImg/r.png",
    ruby: "assets/extetionImg/ruby.png",
    scss: "assets/extetionImg/scss.png",
    sql: "assets/extetionImg/sql.png",
    swift: "assets/extetionImg/swift.png",
    ts: "assets/extetionImg/typescript.png",
    vb: "assets/extetionImg/vb.png",
    xml: "assets/extetionImg/xml.png",
    yaml: "assets/extetionImg/yaml.png"
}
//funções que controlam o drop folder
function allowDrop(ev, that) {

    tabopentab.style.background = "transparent"//"#32485c"
    ev.preventDefault();
}

function drop(ev, that) {
    that.style.zIndex = 0
    ev.preventDefault()
    tabopentab.style.background = "rgba(52, 50, 50, 0.97"
    createSidebarDirTab(path.join(ev.dataTransfer.files[0].path), "folder", undefined, "erase")
    ev.preventDefault()
}
function leave(that) {
    that.style.zIndex = 0
    tabopentab.style.background = 'rgba(52, 50, 50, 0.97'
}
//template para os botões de criação de ficheiros e directorios
const createButton = `
<div class="toggleCreate2">
    <span class="btn btn-default btn-xs noColor">≡</span>
</div>
<div class="mainnav2 btn dropFiles">
    <div class="ulTemplate2">
        <section class="liTemplpate2 btn-default">
            <div style="margin-left: -3px">new file</div>
        </section>
        <section class="liTemplpate btn-default">
            <div style="margin-left: -3px">new folder</div>
        </section>
    </div>
</div>
`
/*function drag(ev) {
    ev.dataTransfer.setData("text", ev.target.id);
    ev.preventDefault();
}*/

/*
function ak() {
    if (init) {
        var arr = init.win.editor.getActions()
        for (var i = 0; i < arr.length; i++) {
            if (arr[i].label === "Command Palette") {
                return arr[i]
            }
        }
    }
}
function ak2() {
    if (init) {
        var arr = init.win.editor.getActions()
        for (var i = 0; i < arr.length; i++) {
            if (arr[i].label === "Delete Line") {
                return arr[i]
            }
        }
    }
}

//var arrObj = ak()

//arrObj.run("Delete Line")*/
