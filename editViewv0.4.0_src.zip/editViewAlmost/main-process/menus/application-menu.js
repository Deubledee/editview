const electron = require('electron')
const app = electron.app
const dialog = require('electron').dialog
const path = require('path')
const ipc = require('electron').ipcMain
ipc.on('openFileInTab', function (event, path, tab) {  
  console.log("it hit here 2")
     event.sender.send("load-file", path.split(), tab)  
})

//\\\\in action\\\\

ipc.on("get-process", function (event) {
  let plat = process.platform
  event.sender.send("process", plat)
})

ipc.on("getVersion", function (event, app) {
  let version = electron.app.getVersion()
  event.sender.send("version", version)
})
