const electron = require('electron')
const app = electron.app
const dialog = electron.dialog
const globalShortcut = electron.globalShortcut

app.on('ready', function () {
	//CommandOrControl+
  globalShortcut.register('CommandOrControl+k', function () {
   app.exit(0)
  })
  
})

app.on('will-quit', function () {
  globalShortcut.unregisterAll()
})
